//
// Created by Libin Zhou on 4/20/20.
//

#ifndef DBX1000_RUBIS_CONST_H
#define DBX1000_RUBIS_CONST_H

#endif //DBX1000_RUBIS_CONST_H
enum{
    I_IID,
    I_SELLER,
    I_RESERVE_PRICE,
    I_INITIAL_PRICE,
    I_START_DATE,
    I_QUANTITY,
    I_NUM_OF_BIDS,
    I_MAX_BID,
    I_END_DATE
};
enum{
    BID_ID,
    BID_KEY,
    BID_MAX_BID,
    BID_BID,
    BID_QUANTITY,
    BID_DATE
};
enum{
    BN_ID,
    BN_KEY,
    BN_QUANTITY,
    BN_DATE
};